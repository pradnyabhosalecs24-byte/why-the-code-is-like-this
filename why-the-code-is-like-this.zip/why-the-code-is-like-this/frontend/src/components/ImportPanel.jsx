import { useEffect, useRef, useState } from 'react';
import { api } from '../lib/api.js';
import { Notice, Spinner } from './ui.jsx';

const STAGES = ['connecting', 'fetching', 'repository', 'commits', 'pulls', 'issues', 'files', 'building', 'writing', 'done'];

export default function ImportPanel({ disabled, githubToken, onImported }) {
  const [url, setUrl] = useState('');
  const [mode, setMode] = useState('incremental');
  const [job, setJob] = useState(null);
  const [error, setError] = useState(null);
  const timer = useRef(null);

  useEffect(() => () => clearTimeout(timer.current), []);

  const poll = (id) => {
    timer.current = setTimeout(async () => {
      try {
        const { job } = await api.job(id);
        setJob(job);
        if (job.status === 'running') poll(id);
        else if (job.status === 'done') onImported(job.repo);
      } catch (err) {
        setError(err.message);
      }
    }, 1200);
  };

  const submit = async (e) => {
    e.preventDefault();
    setError(null);
    try {
      const { job } = await api.startImport(url.trim(), mode);
      setJob(job);
      poll(job.id);
    } catch (err) {
      setError(err.message);
    }
  };

  const running = job?.status === 'running';
  const stageIdx = job ? Math.max(0, STAGES.indexOf(job.stage)) : 0;

  return (
    <section className="panel">
      <h3 className="panel-title">Import repository</h3>
      <form onSubmit={submit} className="import-form">
        <label htmlFor="repo-url" className="sr-only">GitHub repository URL</label>
        <input
          id="repo-url"
          className="input mono"
          placeholder="https://github.com/owner/repo"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          disabled={running}
          required
          maxLength={300}
        />
        <div className="row">
          <select className="input select" value={mode} onChange={(e) => setMode(e.target.value)} disabled={running} aria-label="Import mode">
            <option value="incremental">Incremental update</option>
            <option value="full">Full re-import</option>
          </select>
          <button className="btn btn-primary" disabled={disabled || running || !url.trim()}>
            {running ? 'Importing…' : 'Import'}
          </button>
        </div>
      </form>
      {!githubToken && <p className="hint">No GITHUB_TOKEN: GitHub allows 60 requests/hour, enough only for very small repos.</p>}
      {error && <Notice tone="danger">{error}</Notice>}
      {job && (
        <div className="job">
          <div className="progress" aria-hidden="true">
            <div className={`progress-bar ${job.status}`} style={{ width: `${job.status === 'done' ? 100 : (stageIdx / (STAGES.length - 1)) * 100}%` }} />
          </div>
          <div className="job-line">
            {running ? <Spinner label={job.stage} /> : <span className={`badge status-${job.status === 'done' ? 'current' : 'disputed'}`}>{job.status}</span>}
            <span className="muted small">{job.detail}</span>
          </div>
          {job.status === 'failed' && <Notice tone="danger" title={job.error?.code}>{job.error?.message}</Notice>}
          {job.status === 'done' && job.result && (
            <p className="small muted">
              {job.result.totals.commits} commits · {job.result.totals.pulls} PRs · {job.result.totals.issues} issues · {job.result.decisions} decision candidates
              {job.result.githubRequests ? ` · ${job.result.githubRequests} GitHub requests` : ''}
            </p>
          )}
        </div>
      )}
    </section>
  );
}
