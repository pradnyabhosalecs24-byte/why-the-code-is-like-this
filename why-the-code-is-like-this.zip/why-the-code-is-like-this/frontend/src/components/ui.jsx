import { LABEL_COLORS } from '../lib/api.js';

export function Notice({ tone = 'info', title, children }) {
  return (
    <div className={`notice notice-${tone}`} role={tone === 'danger' ? 'alert' : 'status'}>
      {title && <strong>{title}. </strong>}
      {children}
    </div>
  );
}

export function Spinner({ label = 'Loading' }) {
  return (
    <span className="spinner" role="status">
      <span className="spinner-dot" aria-hidden="true" />
      {label}
    </span>
  );
}

export function StatusBadge({ status }) {
  if (!status) return null;
  return <span className={`badge status-${status}`}>{status}</span>;
}

export function LabelTag({ label }) {
  return (
    <span className="label-tag">
      <i style={{ background: LABEL_COLORS[label] || 'var(--muted)' }} aria-hidden="true" />
      {label}
    </span>
  );
}

export function ExtLink({ href, children }) {
  if (!href) return <span className="muted">{children}</span>;
  return (
    <a href={href} target="_blank" rel="noopener noreferrer" className="ext">
      {children}
      <span aria-hidden="true"> ↗</span>
    </a>
  );
}
