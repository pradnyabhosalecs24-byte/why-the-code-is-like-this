import { createApp } from './app.js';
import { config, credentialStatus } from './config/env.js';
import { log } from './middleware/errors.js';
import { storeHealth } from './services/graph/store.js';

const app = createApp();

app.listen(config.port, async () => {
  log.info(`TraceWhy API listening on http://localhost:${config.port}`);
  const creds = credentialStatus();
  log.info('Credentials present', creds);
  const graph = await storeHealth();
  if (!graph.ok) log.warn(`Graph database not ready: ${graph.message}`);
  else log.info(`Graph backend ready (${graph.backend})`);
  if (!creds.github) log.warn('GITHUB_TOKEN not set: GitHub allows only 60 requests/hour. Imports will be small or rate limited.');
  if (!creds.openai) log.warn('OPENAI_API_KEY not set: answers use the extractive composer (no LLM).');
});
