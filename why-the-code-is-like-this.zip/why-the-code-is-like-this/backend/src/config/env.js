import dotenv from 'dotenv';

dotenv.config();

const int = (name, fallback) => {
  const raw = process.env[name];
  if (raw === undefined || raw === '') return fallback;
  const n = Number.parseInt(raw, 10);
  return Number.isFinite(n) && n >= 0 ? n : fallback;
};

const str = (name, fallback = '') => (process.env[name] ?? fallback).trim();

export const config = {
  port: int('PORT', 4000),
  corsOrigins: str('CORS_ORIGINS', 'http://localhost:5173')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean),
  graphBackend: str('GRAPH_BACKEND', 'neo4j').toLowerCase(),
  neo4j: {
    uri: str('NEO4J_URI'),
    username: str('NEO4J_USERNAME', 'neo4j'),
    password: str('NEO4J_PASSWORD'),
    database: str('NEO4J_DATABASE', 'neo4j'),
  },
  github: {
    token: str('GITHUB_TOKEN'),
    timeoutMs: int('GITHUB_TIMEOUT_MS', 15000),
  },
  openai: {
    apiKey: str('OPENAI_API_KEY'),
    model: str('OPENAI_MODEL', 'gpt-4o-mini'),
    refineDecisions: str('OPENAI_REFINE_DECISIONS', 'false') === 'true',
    timeoutMs: int('OPENAI_TIMEOUT_MS', 45000),
  },
  limits: {
    maxCommits: int('IMPORT_MAX_COMMITS', 300),
    maxCommitDetails: int('IMPORT_MAX_COMMIT_DETAILS', 120),
    maxPulls: int('IMPORT_MAX_PULLS', 60),
    maxIssues: int('IMPORT_MAX_ISSUES', 80),
    maxTimelines: int('IMPORT_MAX_TIMELINES', 30),
    maxFiles: int('IMPORT_MAX_FILES', 150),
    maxFileBytes: int('IMPORT_MAX_FILE_BYTES', 120000),
  },
};

/** Which credentials are present. Never returns the secrets themselves. */
export function credentialStatus() {
  const neo4jConfigured = Boolean(config.neo4j.uri && config.neo4j.password);
  return {
    graphBackend: config.graphBackend,
    neo4j: neo4jConfigured,
    github: Boolean(config.github.token),
    openai: Boolean(config.openai.apiKey),
    openaiModel: config.openai.apiKey ? config.openai.model : null,
  };
}
