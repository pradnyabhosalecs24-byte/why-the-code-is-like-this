import OpenAI from 'openai';

/** Minimal OpenAI wrapper returning parsed JSON. Model is configurable per call. */
export function createLlm({ apiKey, model, timeoutMs = 45000 }) {
  if (!apiKey) return null;
  const client = new OpenAI({ apiKey, timeout: timeoutMs, maxRetries: 2 });
  return {
    model,
    async completeJSON({ system, user, model: override, maxTokens = 900 }) {
      const res = await client.chat.completions.create({
        model: override || model,
        temperature: 0,
        max_tokens: maxTokens,
        response_format: { type: 'json_object' },
        messages: [
          { role: 'system', content: system },
          { role: 'user', content: user },
        ],
      });
      const text = res.choices?.[0]?.message?.content || '{}';
      try {
        return JSON.parse(text);
      } catch {
        return {};
      }
    },
  };
}
